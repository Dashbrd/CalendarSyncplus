﻿namespace U2UConsult.WPF.Localization.Sample
{
    using System;
    using System.Globalization;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Input;
    using WPFLocalizeExtension.Engine;
    using WPFLocalizeExtension.Extensions;

    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        /// <summary>
        /// Initializes a new instance of the MainWindow class.
        /// </summary>
        public MainWindow()
        {
            InitializeComponent();
        }

        /// <summary>
        /// The window is laid out, rendered, and ready for interaction.
        /// </summary>
        /// <param name="sender">Sender of the event (MainWindow).</param>
        /// <param name="e">Event arguments.</param>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // Dynamic
            LocTextExtension loc = new LocTextExtension("U2UConsult.WPF.Localization.Sample:Translations:Pumpkin");
            loc.SetBinding(this.PumpkinTextBlock, TextBlock.TextProperty);

            // Static, with custom error handling
            string pinguin = this.GetLocalizedValue(
                "U2UConsult.WPF.Localization.Sample",
                "Translations",
                "Pinguin",
                CultureInfo.GetCultureInfo("nl-BE"));
            this.PinguinTextBlock.Text = pinguin;

            this.SwitchCulture(CultureInfo.CurrentCulture.Name);
        }

        /// <summary>
        /// Looks up a localized string.
        /// </summary>
        /// <param name="resourceAssembly">Assembly containing the resource.</param>
        /// <param name="resourceDictionary">Dictionary containing the resource.</param>
        /// <param name="resourceKey">Identifier of the resource.</param>
        /// <param name="cultureToUse">The culture to use.</param>
        /// <returns>The value of the resource; or the key prefixed with '@' if not found.</returns>
        private string GetLocalizedValue(
            string resourceAssembly,
            string resourceDictionary,
            string resourceKey,
            CultureInfo cultureToUse)
        {
            try
            {
                return LocalizeDictionary.Instance.GetLocalizedObject<string>(
                             resourceAssembly,
                             resourceDictionary,
                             resourceKey,
                             cultureToUse);
            }
            catch (Exception)
            {
                return "@" + resourceKey;
            }
        }

        /// <summary>
        /// Changes the culture to "nl-BE".
        /// </summary>
        /// <param name="sender">Sender of the event (Image).</param>
        /// <param name="e">Event arguments.</param>
        private void Dutch_Click(object sender, MouseButtonEventArgs e)
        {
            this.SwitchCulture("nl-BE");
        }

        /// <summary>
        /// Changes the culture to "fr-NL", which doesn't exist.
        /// </summary>
        /// <param name="sender">Sender of the event (Image).</param>
        /// <param name="e">Event arguments.</param>
        private void French_Click(object sender, MouseButtonEventArgs e)
        {
            this.SwitchCulture("fr-NL");
        }

        /// <summary>
        /// Changes the culture to "en-US".
        /// </summary>
        /// <param name="sender">Sender of the event (Image).</param>
        /// <param name="e">Event arguments.</param>
        private void AmericanEnglish_Click(object sender, MouseButtonEventArgs e)
        {
            this.SwitchCulture("en-US");
        }

        /// <summary>
        /// Changes the culture to "en-GB".
        /// </summary>
        /// <param name="sender">Sender of the event (Image).</param>
        /// <param name="e">Event arguments.</param>
        private void BritishEnglish_Click(object sender, MouseButtonEventArgs e)
        {
            this.SwitchCulture("en-GB");
        }

        /// <summary>
        /// Changes the culture to "dz-BT".
        /// </summary>
        /// <param name="sender">Sender of the event (Image).</param>
        /// <param name="e">Event arguments.</param>
        /// <remarks>This locale is not installed by default on all systems.</remarks>
        private void Dzongkha_Click(object sender, MouseButtonEventArgs e)
        {
            this.SwitchCulture("dz-BT");
        }

        /// <summary>
        /// Switches the localization culture.
        /// </summary>
        /// <param name="culture">ISO code of the new culture.</param>
        private void SwitchCulture(string culture)
        {
            CultureInfo ci = CultureInfo.InvariantCulture;
            try
            {
                ci = new CultureInfo(culture);
            }
            catch (CultureNotFoundException)
            {
                try
                {
                    // Try language without region
                    ci = new CultureInfo(culture.Substring(0, 2));
                }
                catch (Exception)
                {
                    ci = CultureInfo.InvariantCulture;
                }
            }
            finally
            {
                LocalizeDictionary.Instance.Culture = ci;
                this.CultureTextBlock.Text = ci.EnglishName;
            }
        }
    }
}
